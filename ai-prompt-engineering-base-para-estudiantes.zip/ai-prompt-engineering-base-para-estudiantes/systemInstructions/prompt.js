const medicos = ``

const estudios = ``

export const instrucciones = ``